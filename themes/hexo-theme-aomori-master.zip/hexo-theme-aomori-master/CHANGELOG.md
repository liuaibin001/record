# 1.15.0

### Features

- Feat: New badge for Sticky and Repost

# 1.14.0

### Features

- Feat: Valine support
- Feat: Friends page style

# 1.13.0

### Features

- New menu style
- Bump package

# 1.12.0

### Features

- Add LazyLoad for index page
- Style adjustment

# 1.11.2

### Bug Fixes

- Fixed footer copyright

# 1.11.1

### Bug Fixes

- Fixed wrong cover image selection

# 1.11.0

### Features

- All Style adjustment 

# 1.10.2

### Bug Fixes

- Sidebar layout fixed

# 1.10.1

### Features

- Update packages

# 1.10.0

### Features

- Add Cover Video Plugin
- Add Article Video Plugin

### Bug Fixes

- Sidebar height repaired

# 1.9.0

### Features

- Add Article Swiper
- Add picture preview

### Bug Fixes

- Sidebar height repaired
